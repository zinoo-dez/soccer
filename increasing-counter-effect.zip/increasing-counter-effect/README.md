# Countfect
Simple counter effect plugin with the help of Jquery ⏳
# Required 
jQuery
# Example usage
```html
<h1 class="countfect" delay="5000" data-num="36000"></h1>
```
